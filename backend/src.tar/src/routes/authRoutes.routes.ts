import express, { Request, Response } from 'express';
import { User } from '../models/userSchema.model';
import { Hotel } from '../models/hotelSchema.model';
import bcrypt from 'bcryptjs';

const router = express.Router();

router.post('/login', async (req: Request, res: Response) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({ message: "Email and password are required" });
        }

        const hotel = await Hotel.findOne({ email });
        if (hotel) {
            const isMatch = await bcrypt.compare(password, hotel.password);
            if (isMatch) {
                const { password: _, ...hotelWithoutPassword } = hotel.toObject();
                return res.status(200).json({
                    message: "Login successful",
                    data: hotelWithoutPassword,
                    role: "HOTEL_HOST"
                });
            }
        }

        const user = await User.findOne({ email });
        if (user) {
            const isMatch = await bcrypt.compare(password, user.password);
            if (!isMatch) return res.status(401).json({ message: "Invalid credentials" });

            const { password: _, ...userWithoutPassword } = user.toObject();
            return res.status(200).json({
                message: "Login successful",
                data: userWithoutPassword,
                role: user.role 
            });
        }

        return res.status(401).json({ message: "Invalid credentials" });

    } catch (error: any) {
        res.status(500).json({ message: error.message });
    }
});

router.get('/users', async (req: Request, res: Response) => {
    try {
        const requesterId = req.headers['userid'];
        if (!requesterId) {
            return res.status(401).json({ message: 'Authentication required.' });
        }

        const requester = await User.findOne({ userId: Number(requesterId) });
        if (!requester || requester.role !== 'ADMIN') {
            return res.status(403).json({ message: 'Forbidden: Admin access only.' });
        }

        const users = await User.find()
            .select('-password')
            .sort({ createdAt: -1 });

        return res.status(200).json({ data: users });
    } catch (error: any) {
        res.status(500).json({ message: error.message });
    }
});
export default router;
