import { LoginForm } from '../components/forms/auth/LoginForm.tsx';

export const LoginPage = () => {
    return (
        <div className="min-h-screen pt-24 pb-12 px-4 flex items-center justify-center bg-gray-50 relative overflow-hidden">
            <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-[var(--tm-liquid-blue)]/20 rounded-full blur-[100px] pointer-events-none" />
            <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-[var(--tm-ethereal-purple)]/20 rounded-full blur-[100px] pointer-events-none" />
            
            <div className="w-full z-10">
                <LoginForm />
            </div>
        </div>
    );
};