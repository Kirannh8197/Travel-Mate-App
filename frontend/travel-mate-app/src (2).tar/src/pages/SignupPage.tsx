import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { UserRegisterForm } from '../components/forms/auth/UserRegisterForm';
import { HotelRegisterForm } from '../components/forms/auth/HotelRegisterForm';

export const SignupPage = () => {
    // State to toggle between forms
    const [isHost, setIsHost] = useState(false);

    return (
        <div className="min-h-screen pt-24 pb-12 px-4 flex flex-col items-center justify-center bg-gray-50 relative overflow-hidden">
            {/* Ambient background elements */}
            <div className={`absolute top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full blur-[100px] pointer-events-none transition-colors duration-700 ${isHost ? 'bg-amber-500/20' : 'bg-[var(--tm-liquid-blue)]/20'}`} />
            
            <div className="w-full max-w-xl z-10 flex flex-col items-center">
                
                {/* Clean Toggle Switch */}
                <div className="bg-white p-1 rounded-xl shadow-sm border border-gray-200 flex gap-1 mb-8">
                    <button 
                        onClick={() => setIsHost(false)}
                        className={`px-6 py-2 rounded-lg font-bold text-sm transition-all ${!isHost ? 'bg-gray-900 text-white shadow-md' : 'text-gray-500 hover:bg-gray-50'}`}
                    >
                        Traveler
                    </button>
                    <button 
                        onClick={() => setIsHost(true)}
                        className={`px-6 py-2 rounded-lg font-bold text-sm transition-all ${isHost ? 'bg-amber-500 text-white shadow-md' : 'text-gray-500 hover:bg-gray-50'}`}
                    >
                        Hotel Host
                    </button>
                </div>

                {/* Form Rendering with smooth fade transition */}
                <div className="w-full">
                    <AnimatePresence mode="wait">
                        {isHost ? (
                            <motion.div key="host" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
                                <HotelRegisterForm />
                            </motion.div>
                        ) : (
                            <motion.div key="user" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }}>
                                <UserRegisterForm />
                            </motion.div>
                        )}
                    </AnimatePresence>
                </div>

                <div className="mt-8 text-center text-sm font-medium text-gray-500">
                    Already have an account?{' '}
                    <Link to="/login" className="text-gray-900 font-bold hover:underline">
                        Sign in instead
                    </Link>
                </div>
            </div>
        </div>
    );
};