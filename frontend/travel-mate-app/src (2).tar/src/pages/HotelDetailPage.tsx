import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { MapPin, Star, Wifi, Coffee, Car, Shield } from 'lucide-react';
import { hotelService } from '../services/hotel.service';
import { BookingReservationForm } from '../components/forms/booking/BookingReservationFrom';

export const HotelDetailPage = () => {
    const { hotelId } = useParams<{ hotelId: string }>();
    const [hotel, setHotel] = useState<any>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchHotel = async () => {
            if (!hotelId) return;
            try {
                const data = await hotelService.getHotelById(hotelId);
                setHotel(data);
            } catch (error) {
                console.error("Failed to fetch hotel details", error);
            } finally {
                setLoading(false);
            }
        };
        fetchHotel();
    }, [hotelId]);

    const imgUrl = (path: string) => path.startsWith('http') ? path : `http://localhost:5000${path}`;

    if (loading) return <div className="min-h-screen pt-24 flex justify-center items-center"><div className="w-10 h-10 border-4 border-[var(--tm-liquid-blue)] border-t-transparent rounded-full animate-spin" /></div>;
    if (!hotel) return <div className="min-h-screen pt-24 text-center text-red-500 font-bold">Hotel not found.</div>;

    // Map common amenity names to icons visually
    const getAmenityIcon = (am: string) => {
        const lower = am.toLowerCase();
        if (lower.includes('wifi')) return <Wifi className="w-5 h-5" />;
        if (lower.includes('breakfast') || lower.includes('coffee')) return <Coffee className="w-5 h-5" />;
        if (lower.includes('park')) return <Car className="w-5 h-5" />;
        return <Shield className="w-5 h-5" />;
    };

    return (
        <div className="elite-container py-24 min-h-screen">
            
            {/* ── Header ── */}
            <div className="mb-8">
                <h1 className="text-4xl md:text-5xl font-serif font-black text-gray-900 mb-4">{hotel.name}</h1>
                <div className="flex items-center gap-4 text-sm font-bold text-gray-500">
                    <span className="flex items-center gap-1 text-amber-500 bg-amber-50 px-2 py-1 rounded-lg border border-amber-100"><Star className="w-4 h-4 fill-amber-500" /> {hotel.rating || 'New'}</span>
                    <span className="flex items-center gap-1"><MapPin className="w-4 h-4 text-gray-400" /> {hotel.address?.city}, {hotel.address?.country}</span>
                </div>
            </div>

            {/* ── Image Gallery ── */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-12 h-[50vh] min-h-[400px]">
                <div className="md:col-span-2 relative rounded-3xl overflow-hidden shadow-xl">
                    {hotel.images?.[0] && <img src={imgUrl(hotel.images[0])} alt="Main" className="absolute inset-0 w-full h-full object-cover" />}
                </div>
                <div className="hidden md:flex flex-col gap-4 h-full">
                    <div className="flex-1 relative rounded-3xl overflow-hidden shadow-lg">
                        {hotel.images?.[1] ? <img src={imgUrl(hotel.images[1])} alt="Sub 1" className="absolute inset-0 w-full h-full object-cover" /> : <div className="absolute inset-0 bg-gray-100" />}
                    </div>
                    <div className="flex-1 relative rounded-3xl overflow-hidden shadow-lg">
                        {hotel.images?.[2] ? <img src={imgUrl(hotel.images[2])} alt="Sub 2" className="absolute inset-0 w-full h-full object-cover" /> : <div className="absolute inset-0 bg-gray-100" />}
                    </div>
                </div>
            </div>

            {/* ── Content Grid ── */}
            <div className="grid lg:grid-cols-3 gap-12">
                <div className="lg:col-span-2 space-y-12">
                    {/* Description */}
                    <section>
                        <h2 className="text-2xl font-black font-serif text-gray-900 mb-4">About this sanctuary</h2>
                        <p className="text-gray-600 leading-relaxed text-lg">{hotel.description || 'Experience luxury and comfort at its finest. Book your stay today.'}</p>
                    </section>

                    {/* Amenities */}
                    {hotel.amenities && hotel.amenities.length > 0 && (
                        <section className="pt-8 border-t border-gray-100">
                            <h2 className="text-2xl font-black font-serif text-gray-900 mb-6">Premium Amenities</h2>
                            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                                {hotel.amenities.map((am: string, i: number) => (
                                    <div key={i} className="flex items-center gap-3 text-gray-700 font-medium">
                                        <div className="w-10 h-10 rounded-xl bg-purple-50 text-[var(--tm-ethereal-purple)] flex items-center justify-center">
                                            {getAmenityIcon(am)}
                                        </div>
                                        {am}
                                    </div>
                                ))}
                            </div>
                        </section>
                    )}
                </div>

                {/* ── Right Panel: Booking Form ── */}
                <div className="lg:col-span-1 relative">
                    <BookingReservationForm hotel={hotel} />
                </div>
            </div>
        </div>
    );
};