import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { X, ImagePlus, Loader2, Save, Check } from 'lucide-react';
import { hotelService } from '../../../services/hotel.service';

const BACKEND = import.meta.env.VITE_API_BASE_URL?.replace('/api', '') || 'http://localhost:5000';
const AMENITY_OPTIONS = ['WiFi', 'Pool', 'Spa', 'Gym', 'Restaurant', 'Bar', 'Valet', 'Parking'];
const imgUrl = (p: string) => !p ? '' : p.startsWith('http') ? p : p.startsWith('/') ? `${BACKEND}${p}` : `${BACKEND}/uploads/${p}`;

export const HotelEditForm = ({ hotel, onClose, onSaved }: { hotel: any; onClose: () => void; onSaved: (updated: any) => void }) => {
    const [name, setName] = useState(hotel.name || '');
    const [description, setDescription] = useState(hotel.description || '');
    const [price, setPrice] = useState(String(hotel.pricePerNight || ''));
    const [amenities, setAmenities] = useState<string[]>(hotel.amenities || []);
    const [newFiles, setNewFiles] = useState<File[]>([]);
    const [previews, setPreviews] = useState<string[]>([]);
    
    const [saving, setSaving] = useState(false);
    const [saved, setSaved] = useState(false);
    const [saveError, setSaveError] = useState('');
    const fileInputRef = useRef<HTMLInputElement>(null);

    const toggleAmenity = (am: string) =>
        setAmenities(prev => prev.includes(am) ? prev.filter(a => a !== am) : [...prev, am]);

    const handleFiles = (e: React.ChangeEvent<HTMLInputElement>) => {
        const files = Array.from(e.target.files || []);
        setNewFiles(files);
        setPreviews(files.map(f => URL.createObjectURL(f)));
    };

    const handleSave = async () => {
        setSaving(true);
        setSaveError('');
        
        const fd = new FormData();
        fd.append('name', name);
        fd.append('description', description);
        fd.append('pricePerNight', price);
        fd.append('amenities', JSON.stringify(amenities)); // Keep this exactly as your old code had it!
        
        newFiles.forEach(f => fd.append('images', f));

        try {
            // Using the clean Axios service!
            const res = await hotelService.updateHotel(hotel._id, fd);
            
            setSaved(true);
            setTimeout(() => {
                onSaved(res.data || res); // Pass updated data back to dashboard
            }, 1000);
        } catch (e: any) {
            setSaveError(e.response?.data?.message || 'Network error. Please try again.');
        } finally {
            setSaving(false);
        }
    };

    return (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4"
            onClick={onClose}>
            
            <motion.div initial={{ opacity: 0, scale: 0.95, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95, y: 20 }}
                onClick={e => e.stopPropagation()}
                className="bg-white rounded-3xl shadow-2xl max-w-lg w-full overflow-hidden max-h-[90vh] flex flex-col">
                
                {/* Header */}
                <div className="bg-gradient-to-br from-[var(--tm-deep-indigo)] to-[var(--tm-ethereal-purple)] p-6 text-white shrink-0">
                    <div className="flex justify-between items-start">
                        <div>
                            <p className="text-white/60 text-xs font-bold uppercase tracking-widest mb-1">Host Dashboard</p>
                            <h2 className="text-2xl font-serif font-black">Edit Your Hotel</h2>
                        </div>
                        <button onClick={onClose} className="w-8 h-8 bg-white/20 hover:bg-white/30 rounded-full flex items-center justify-center transition-all">
                            <X className="w-4 h-4" />
                        </button>
                    </div>
                </div>

                {/* Scrollable Form Body */}
                <div className="p-6 space-y-5 overflow-y-auto">
                    {/* Name */}
                    <div>
                        <label className="text-xs font-black text-gray-500 uppercase tracking-wider mb-1.5 block">Hotel Name</label>
                        <input value={name} onChange={e => setName(e.target.value)}
                            className="w-full px-4 py-3 bg-gray-50 border-2 border-gray-200 rounded-2xl text-sm font-bold focus:border-[var(--tm-ethereal-purple)] focus:outline-none focus:ring-4 focus:ring-[var(--tm-ethereal-purple)]/10 transition-all" />
                    </div>
                    
                    {/* Description */}
                    <div>
                        <label className="text-xs font-black text-gray-500 uppercase tracking-wider mb-1.5 block">Description</label>
                        <textarea value={description} onChange={e => setDescription(e.target.value)} rows={3}
                            className="w-full px-4 py-3 bg-gray-50 border-2 border-gray-200 rounded-2xl text-sm font-medium focus:border-[var(--tm-ethereal-purple)] focus:outline-none focus:ring-4 focus:ring-[var(--tm-ethereal-purple)]/10 transition-all resize-none" />
                    </div>
                    
                    {/* Price */}
                    <div>
                        <label className="text-xs font-black text-gray-500 uppercase tracking-wider mb-1.5 block">Price Per Night (₹)</label>
                        <input value={price} onChange={e => setPrice(e.target.value)} type="number"
                            className="w-full px-4 py-3 bg-gray-50 border-2 border-gray-200 rounded-2xl text-sm font-bold focus:border-[var(--tm-ethereal-purple)] focus:outline-none focus:ring-4 focus:ring-[var(--tm-ethereal-purple)]/10 transition-all" />
                    </div>
                    
                    {/* Amenities Toggle (Restored!) */}
                    <div>
                        <label className="text-xs font-black text-gray-500 uppercase tracking-wider mb-2 block">Amenities</label>
                        <div className="flex flex-wrap gap-2">
                            {AMENITY_OPTIONS.map(am => (
                                <button key={am} onClick={() => toggleAmenity(am)} type="button"
                                    className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all border ${amenities.includes(am) ? 'bg-[var(--tm-ethereal-purple)] text-white border-transparent shadow-md' : 'bg-gray-50 border-gray-200 text-gray-500 hover:border-gray-400'}`}>
                                    {am}
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* Photo Upload & Previews (Restored!) */}
                    <div>
                        <label className="text-xs font-black text-gray-500 uppercase tracking-wider mb-2 block">
                            Photos {newFiles.length > 0 ? <span className="text-[var(--tm-ethereal-purple)]">({newFiles.length} new selected — will replace existing)</span> : <span className="text-gray-400">(Upload to replace existing photos)</span>}
                        </label>
                        <input ref={fileInputRef} type="file" accept="image/*" multiple onChange={handleFiles} className="hidden" />

                        {/* Current photos preview */}
                        {previews.length === 0 && hotel.images?.length > 0 && (
                            <div className="flex gap-2 flex-wrap mb-3">
                                {hotel.images.slice(0, 4).map((img: string, i: number) => (
                                    <div key={i} className="w-16 h-12 rounded-xl overflow-hidden border-2 border-gray-200">
                                        <img src={imgUrl(img)} alt="" className="w-full h-full object-cover" />
                                    </div>
                                ))}
                                {hotel.images.length > 4 && <div className="w-16 h-12 rounded-xl bg-gray-100 border-2 border-gray-200 flex items-center justify-center text-xs font-black text-gray-500">+{hotel.images.length - 4}</div>}
                            </div>
                        )}
                        
                        {/* New selected photos preview */}
                        {previews.length > 0 && (
                            <div className="flex gap-2 flex-wrap mb-3">
                                {previews.map((p, i) => (
                                    <div key={i} className="w-16 h-12 rounded-xl overflow-hidden border-2 border-[var(--tm-ethereal-purple)]">
                                        <img src={p} alt="" className="w-full h-full object-cover" />
                                    </div>
                                ))}
                            </div>
                        )}

                        <button onClick={() => fileInputRef.current?.click()} type="button"
                            className="w-full py-3 border-2 border-dashed border-gray-300 rounded-2xl text-sm font-bold text-gray-500 hover:border-[var(--tm-ethereal-purple)] hover:text-[var(--tm-ethereal-purple)] transition-all flex items-center justify-center gap-2">
                            <ImagePlus className="w-4 h-4" />
                            {newFiles.length > 0 ? `${newFiles.length} photo${newFiles.length > 1 ? 's' : ''} selected — click to change` : 'Select new photos'}
                        </button>
                    </div>

                    {/* Submit Area */}
                    {saveError && (
                        <div className="bg-red-50 border border-red-200 rounded-2xl p-3 text-sm text-red-700 font-bold">
                            ⚠ {saveError}
                        </div>
                    )}
                    <button onClick={handleSave} disabled={saving || saved} type="button"
                        className="w-full py-4 rounded-2xl font-black text-white text-base shadow-xl shadow-[var(--tm-ethereal-purple)]/20 transition-all active:scale-95 disabled:opacity-70 flex items-center justify-center gap-2"
                        style={{ background: 'linear-gradient(135deg, var(--tm-deep-indigo), var(--tm-ethereal-purple))' }}>
                        {saving ? <><Loader2 className="w-5 h-5 animate-spin" />Saving…</>
                            : saved ? <><Check className="w-5 h-5" />Saved!</>
                                : <><Save className="w-5 h-5" />Save Changes</>}
                    </button>
                </div>
            </motion.div>
        </motion.div>
    );
};