import { useEffect, useState } from 'react';
import { useUserStore } from '../../store/useUserStore';
import { Users, Building, Activity, ShieldAlert, CheckCircle, MapPin, Mail } from 'lucide-react';
import { motion } from 'framer-motion';
import { userService } from '../../services/user.service';
import { hotelService } from '../../services/hotel.service';

export const AdminDashboard = () => {
    const { user, role } = useUserStore();
    const [usersList, setUsersList] = useState<any[]>([]);
    const [hotelsList, setHotelsList] = useState<any[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [activeTab, setActiveTab] = useState<'USERS' | 'HOTELS'>('USERS');

    useEffect(() => {
        const fetchAdminData = async () => {
            if (role !== 'ADMIN') return;
            
            try {
                // Fetch both users and hotels concurrently for maximum speed
                const [usersRes, hotelsRes] = await Promise.all([
                    userService.getAllUsers(),
                    hotelService.getAllHotels()
                ]);
                
                // Set data (handling potential nested data objects based on your API structure)
                setUsersList(usersRes.users || usersRes.data || usersRes);
                setHotelsList(hotelsRes.data || hotelsRes);
            } catch (error) {
                console.error('Failed to fetch admin data:', error);
            } finally {
                setIsLoading(false);
            }
        };
        fetchAdminData();
    }, [role]);

    // Security block
    if (!user || role !== 'ADMIN') {
        return <div className="p-12 text-center font-bold text-red-500 min-h-screen pt-32">Security Clearance Required.</div>;
    }

    const imgUrl = (path: string) => path.startsWith('http') ? path : `http://localhost:5000${path}`;

    return (
        <div className="elite-container min-h-screen pb-20">
            
            {/* ── Header ── */}
            <motion.div initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }} className="mb-10 pt-8">
                <p className="text-xs font-black uppercase tracking-[0.25em] text-red-500 mb-2 flex items-center gap-2">
                    <ShieldAlert className="w-4 h-4" /> System Administrator
                </p>
                <h1 className="elite-section-title text-5xl text-gray-900 mb-2">Central Command</h1>
                <p className="text-gray-500 font-medium">Monitor and manage the entire TravelMate ecosystem.</p>
            </motion.div>

            {/* ── High-Level Stats ── */}
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} 
                className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
                <div className="elite-stat-card border-t-4 border-t-[var(--tm-liquid-blue)]">
                    <Users className="w-6 h-6 mb-3 text-[var(--tm-liquid-blue)]" />
                    <p className="text-3xl font-black text-gray-900">{usersList.length}</p>
                    <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mt-1">Total Users</p>
                </div>
                <div className="elite-stat-card border-t-4 border-t-[var(--tm-ethereal-purple)]">
                    <Building className="w-6 h-6 mb-3 text-[var(--tm-ethereal-purple)]" />
                    <p className="text-3xl font-black text-gray-900">{hotelsList.length}</p>
                    <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mt-1">Properties Listed</p>
                </div>
                <div className="elite-stat-card border-t-4 border-t-green-500">
                    <CheckCircle className="w-6 h-6 mb-3 text-green-500" />
                    <p className="text-3xl font-black text-gray-900">System</p>
                    <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mt-1">Operational</p>
                </div>
                <div className="elite-stat-card border-t-4 border-t-amber-500">
                    <Activity className="w-6 h-6 mb-3 text-amber-500" />
                    <p className="text-3xl font-black text-gray-900">Live</p>
                    <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mt-1">Database Sync</p>
                </div>
            </motion.div>

            {/* ── Data Tables ── */}
            <div className="elite-card overflow-hidden">
                {/* Tab Controls */}
                <div className="flex border-b border-gray-100 bg-gray-50/50">
                    <button 
                        onClick={() => setActiveTab('USERS')}
                        className={`flex-1 py-4 font-bold text-sm transition-all ${activeTab === 'USERS' ? 'text-[var(--tm-liquid-blue)] bg-white border-b-2 border-[var(--tm-liquid-blue)] shadow-sm' : 'text-gray-500 hover:bg-gray-100'}`}
                    >
                        User Directory
                    </button>
                    <button 
                        onClick={() => setActiveTab('HOTELS')}
                        className={`flex-1 py-4 font-bold text-sm transition-all ${activeTab === 'HOTELS' ? 'text-[var(--tm-ethereal-purple)] bg-white border-b-2 border-[var(--tm-ethereal-purple)] shadow-sm' : 'text-gray-500 hover:bg-gray-100'}`}
                    >
                        Property Registry
                    </button>
                </div>

                <div className="p-6">
                    {isLoading ? (
                        <div className="flex justify-center p-12">
                            <div className="w-8 h-8 border-[3px] border-gray-200 border-t-gray-800 rounded-full animate-spin" />
                        </div>
                    ) : activeTab === 'USERS' ? (
                        /* USERS LIST */
                        <div className="space-y-3">
                            {usersList.map((u, i) => (
                                <motion.div key={u._id || i} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }} 
                                    className="flex items-center justify-between p-4 rounded-xl border border-gray-100 hover:border-[var(--tm-liquid-blue)]/30 hover:shadow-md transition-all bg-white group">
                                    <div className="flex items-center gap-4">
                                        <div className="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center text-[var(--tm-liquid-blue)] font-bold">
                                            {u.name?.charAt(0) || 'U'}
                                        </div>
                                        <div>
                                            <h3 className="font-bold text-gray-900">{u.name}</h3>
                                            <div className="flex items-center gap-1.5 text-xs text-gray-500 font-medium">
                                                <Mail className="w-3 h-3" /> {u.email}
                                            </div>
                                        </div>
                                    </div>
                                    <div className="text-right">
                                        <span className={`text-xs font-black uppercase px-2.5 py-1 rounded-lg border ${u.role === 'ADMIN' ? 'bg-red-50 text-red-600 border-red-200' : 'bg-gray-50 text-gray-600 border-gray-200'}`}>
                                            {u.role || 'USER'}
                                        </span>
                                        <p className="text-xs text-gray-400 font-mono mt-1 text-right">ID: {u.userId || u._id}</p>
                                    </div>
                                </motion.div>
                            ))}
                        </div>
                    ) : (
                        /* HOTELS LIST */
                        <div className="grid md:grid-cols-2 gap-4">
                            {hotelsList.map((h, i) => (
                                <motion.div key={h._id || i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }} 
                                    className="flex items-center gap-4 p-4 rounded-xl border border-gray-100 hover:border-[var(--tm-ethereal-purple)]/30 hover:shadow-md transition-all bg-white group">
                                    <div className="w-16 h-16 rounded-lg overflow-hidden bg-gray-100 shrink-0">
                                        {h.images?.[0] ? (
                                            <img src={imgUrl(h.images[0])} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" alt="" />
                                        ) : (
                                            <Building className="w-8 h-8 m-4 text-gray-300" />
                                        )}
                                    </div>
                                    <div className="flex-1 min-w-0">
                                        <h3 className="font-bold text-gray-900 truncate">{h.name}</h3>
                                        <div className="flex items-center gap-1 text-xs text-gray-500 font-medium mt-1">
                                            <MapPin className="w-3 h-3 shrink-0" />
                                            <span className="truncate">{h.address?.city}, {h.address?.country}</span>
                                        </div>
                                        <p className="text-xs text-[var(--tm-ethereal-purple)] font-black mt-1">₹{h.pricePerNight} / night</p>
                                    </div>
                                </motion.div>
                            ))}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};